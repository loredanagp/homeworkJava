package LabsFinal.Lab7;

interface GeometryBody{
     double getSurface();
     double getVolume();
}
