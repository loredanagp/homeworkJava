package LabsFinal.Lab8;

public class UnluckyException extends Exception{
    public UnluckyException(){
        super("Ocured an exception with an unlucky number!!!");
    }
}
