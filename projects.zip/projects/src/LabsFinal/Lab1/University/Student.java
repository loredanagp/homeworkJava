package LabsFinal.Lab1.University;

public class Student {
    private String name;
    private int age;
    double avgmark;
    Student(String name, int age, double avgmark) {
        this.name= name;
        this.age=age;
        this.avgmark=avgmark;
    }
}
