package LabsFinal.Lab6.Other;



public class Organisation{

    public static void main( String[] args ) {

    }
}
