package LabsFinal.Lab6.Classes;

public class Department{
    private Staff[] staff;
    public Department(Staff[] staff){
        this.staff=staff;
    }
}
