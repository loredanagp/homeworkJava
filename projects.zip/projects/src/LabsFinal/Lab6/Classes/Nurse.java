package LabsFinal.Lab6.Classes;

import java.util.Date;

public class Nurse extends OperationsStaff{

    public Nurse( Person person, Date joined, String[] education, String[] certification, String[] languages ) {
        super( person, joined, education, certification, languages );
    }
}
