package LabsFinal.Lab6.DataTypes;

public class Address{
    private String address;
    public Address(String address){
        this.address=address;
    }
}
