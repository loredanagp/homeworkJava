package LabsFinal.Lab6.DataTypes;

public class Phone{
    private String number;
    public Phone(String number){
        this.number=number;
    }
}
