package LabsFinal.Lab6.DataTypes;

public class History{
}
