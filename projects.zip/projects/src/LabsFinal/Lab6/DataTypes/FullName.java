package LabsFinal.Lab6.DataTypes;

public class FullName{
    private String givenName;
    private String middleName;
    private String familyName;

public FullName(String givenName,String middleName,String familyName) {
    this.givenName = givenName;
    this.middleName = middleName;
    this.familyName = familyName;
}

}
