package LabsFinal.Lab6.DataTypes;

public enum Gender{
    MALE,FAMALE
}
