package LabsFinal.Lab5;

public class X {
    public String name;

    X(String s){
        this.name=s;
    }

    @Override
    public String toString() {
        return "X{" +
                "name='" + name + '\'' +
                '}';
    }
}
