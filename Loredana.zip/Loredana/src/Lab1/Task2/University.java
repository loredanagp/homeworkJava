package Lab1.Task2;

public class University{
    String name;
    int yearFondation;
    Student[] students;
    double mark;

    University(String name, int yearFondation, Student[] students){
        this.name=name;
        this.yearFondation=yearFondation;
        this.students=students;
        double sum=0;
        for ( int i=0; i<students.length;i++ )
        {
            sum+=students[i].mark;
        }
        this.mark=sum/students.length;

    }

}
