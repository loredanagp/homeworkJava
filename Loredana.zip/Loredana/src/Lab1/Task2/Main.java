package Lab1.Task2;

public class Main{
    public static void main( String[] args ) {
        Student student1= new Student( "Ion",21,8.56 );
        Student student2 = new Student( "Gicu", 20,7.5 );
        Student[] asemstudents={student1,student2};
        University asem= new University( "ASEM", 1991,asemstudents );
        System.out.println(asem.mark);
    }
}
