package Lab1.Task1;

public class Main{


    public static void main( String[] args ) {
        Monitor monitor1=new Monitor("Red",1080,1000);
        monitor1.color="Grey";
        Monitor monitor2= new Monitor( "Yellow",760,1080 );
        System.out.println(monitor1.compareResolution( monitor2 ));
        System.out.println(monitor1.color);
    }
}
