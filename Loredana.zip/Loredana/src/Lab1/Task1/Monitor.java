package Lab1.Task1;

public class Monitor{
   public String color;
   public int dimension;
   public int resolution;
public  Monitor(String color , int dimension, int resolution){
    this.color=color;
   this.dimension=dimension;
    this.resolution=resolution;

}
    public String compareResolution(Monitor o)
    {
        if(this.resolution<o.resolution)
        return "Este mai mica";
        else if (this.resolution==o.resolution)
            return "Este egal";
        else return "Este mai mare";
    }

}
